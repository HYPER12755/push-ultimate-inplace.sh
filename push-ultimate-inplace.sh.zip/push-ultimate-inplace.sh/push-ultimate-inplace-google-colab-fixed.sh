GIT_USER = "HYPER12755"
REPO_NAME = "ULTIMATE-RAT-COLLECTION"
TOKEN = "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"
WORK_TREE = "/content/ULTIMATE-RAT-COLLECTION"

import os
import tempfile
import shutil
import time

os.makedirs(WORK_TREE, exist_ok=True)

!git config --global user.name "HYPER12755"
!git config --global user.email "hyper14917374@gmail.com"

# Store token for git
!git config --global credential.helper store
cred_content = f"https://{TOKEN}:@github.com\n"
with open(os.path.expanduser("~/.git-credentials"), "w") as f:
    f.write(cred_content)

tmp_git_dir = tempfile.mkdtemp()
print(f"Using temporary git dir: {tmp_git_dir}")

REPO_URL = f"https://github.com/{GIT_USER}/{REPO_NAME}.git"  # No token in URL now

!git init --bare "{tmp_git_dir}" >/dev/null
!git --git-dir="{tmp_git_dir}" --work-tree="{WORK_TREE}" remote add origin "{REPO_URL}"
!git --git-dir="{tmp_git_dir}" --work-tree="{WORK_TREE}" add --all
!git --git-dir="{tmp_git_dir}" --work-tree="{WORK_TREE}" commit -m "Upload from Colab" || echo "No changes to commit"
!git --git-dir="{tmp_git_dir}" --work-tree="{WORK_TREE}" branch -m master main
!git --git-dir="{tmp_git_dir}" --work-tree="{WORK_TREE}" push -u origin main --force

# Remove git lock file if exists, then remove folder
lock_file = os.path.join(tmp_git_dir, 'gc.log.lock')
if os.path.exists(lock_file):
    os.remove(lock_file)

time.sleep(1)
shutil.rmtree(tmp_git_dir)

print("✅ Push complete!")